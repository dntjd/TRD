# Coordinate Brush

__Contributions by :__  [nicovain](https://github.com/nicovain), [pmurph0305](https://github.com/pmurph0305)

This Brush displays the coordinates of the it is currently targeting in the Scene view. Use this Brush as an example for creating custom Brushes that display extra visualization features, such as cell coordinate information, while painting a Tilemap.

![Scene View with Coordinate Brush](images/CoordinateBrush.png)